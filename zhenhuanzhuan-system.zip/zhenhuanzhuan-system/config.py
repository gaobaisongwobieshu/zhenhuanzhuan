# config.py
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',        # 你的数据库用户名，通常是 root
    'password': '20050813j', # ⚠️⚠️⚠️ 请在这里填入你的 MySQL 密码
    'database': 'zhz'
}