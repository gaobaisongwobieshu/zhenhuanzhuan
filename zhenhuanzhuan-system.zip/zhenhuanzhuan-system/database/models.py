from database.db_connection import get_db_connection

def get_all_characters():
    conn = get_db_connection()
    if not conn: return []
    cursor = conn.cursor(dictionary=True)
    try:
        # ✨✨✨ 修改：不再用CONCAT生成description，而是直接返回所有字段 ✨✨✨
        query = """
            SELECT 
                character_id as id, name, gender, age, 
                personality_traits, faction, mbti_type
            FROM characters
            ORDER BY character_id DESC 
        """
        cursor.execute(query)
        # ✨✨✨ 新增：为每个角色添加一个简短的description字段用于搜索，不影响原始字段 ✨✨✨
        characters = cursor.fetchall()
        for char in characters:
            char['description'] = f"性格：{char.get('personality_traits', '暂无')}。"
        return characters
    finally:
        cursor.close()
        conn.close()

def get_all_events():
    conn = get_db_connection()
    if not conn: return []
    cursor = conn.cursor(dictionary=True)
    try:
        query = """
            SELECT 
                e.event_id as id, e.event_title as title, e.event_year as year,
                e.importance_level as importance, e.event_description as description,
                ep.title as episode
            FROM events e
            LEFT JOIN episodes ep ON e.episode_id = ep.episode_id
            ORDER BY e.event_year ASC
        """
        cursor.execute(query)
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def get_participants_for_event(event_id):
    conn = get_db_connection()
    if not conn: return []
    cursor = conn.cursor(dictionary=True)
    try:
        query = """
            SELECT c.name as character_name, ce.involvement_type
            FROM character_events ce
            JOIN characters c ON ce.character_id = c.character_id
            WHERE ce.event_id = %s
        """
        cursor.execute(query, (event_id,))
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def update_event_importance(event_id, new_importance):
    conn = get_db_connection()
    if not conn: return False
    cursor = conn.cursor()
    try:
        query = "UPDATE events SET importance_level = %s WHERE event_id = %s"
        cursor.execute(query, (new_importance, event_id))
        conn.commit()
        return cursor.rowcount > 0
    except Exception as e:
        print(f"更新事件重要性失败: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()
        conn.close()

def get_all_relationships():
    conn = get_db_connection()
    if not conn: return []
    cursor = conn.cursor(dictionary=True)
    try:
        query = """
            SELECT
                c1.name AS char1_name,
                c2.name AS char2_name,
                r.relationship_type AS type,
                r.relationship_strength AS strength,
                r.description
            FROM relationships r
            JOIN characters c1 ON r.character_id1 = c1.character_id
            JOIN characters c2 ON r.character_id2 = c2.character_id
            ORDER BY r.relationship_strength DESC
        """
        cursor.execute(query)
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def get_faction_stats():
    conn = get_db_connection()
    if not conn: return []
    cursor = conn.cursor(dictionary=True)
    try:
        query = """
            SELECT faction, COUNT(*) as count
            FROM characters
            WHERE faction IS NOT NULL AND faction != ''
            GROUP BY faction
            ORDER BY count DESC
        """
        cursor.execute(query)
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def get_events_by_year_stats():
    conn = get_db_connection()
    if not conn: return []
    cursor = conn.cursor(dictionary=True)
    try:
        query = """
            SELECT 
                event_year as year,
                COUNT(*) as total_events,
                SUM(CASE WHEN importance_level = '高' THEN 1 ELSE 0 END) as high_importance_events
            FROM events
            WHERE event_year IS NOT NULL
            GROUP BY event_year
            ORDER BY event_year ASC
        """
        cursor.execute(query)
        return cursor.fetchall()
    finally:
        cursor.close()
        conn.close()

def add_character(name, gender, age, personality_traits, faction, mbti_type):
    conn = get_db_connection()
    if not conn: return False, "数据库连接失败"
    cursor = conn.cursor()
    try:
        query = """
            INSERT INTO characters (name, gender, age, personality_traits, faction, mbti_type)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        cursor.execute(query, (name, gender, age, personality_traits, faction, mbti_type))
        conn.commit()
        return True, "角色添加成功"
    except Exception as e:
        print(f"添加角色失败: {e}")
        conn.rollback()
        return False, str(e)
    finally:
        cursor.close()
        conn.close()

def update_character(character_id, name, gender, age, personality_traits, faction, mbti_type):
    conn = get_db_connection()
    if not conn: return False, "数据库连接失败"
    cursor = conn.cursor()
    try:
        query = """
            UPDATE characters
            SET name = %s, gender = %s, age = %s, 
                personality_traits = %s, faction = %s, mbti_type = %s
            WHERE character_id = %s
        """
        cursor.execute(query, (name, gender, age, personality_traits, faction, mbti_type, character_id))
        conn.commit()
        if cursor.rowcount > 0:
            return True, "角色信息更新成功"
        else:
            return False, "未找到该角色或信息未改变"
    except Exception as e:
        print(f"更新角色失败: {e}")
        conn.rollback()
        return False, str(e)
    finally:
        cursor.close()
        conn.close()


def delete_character(character_id):
    conn = get_db_connection()
    if not conn: return False, "数据库连接失败"
    cursor = conn.cursor()
    try:
        # 由于数据库已经设置了外键的ON DELETE CASCADE，
        # 删除characters表中的角色会自动删除character_events和relationships表中相关联的记录。
        query = "DELETE FROM characters WHERE character_id = %s"
        cursor.execute(query, (character_id,))
        conn.commit()
        if cursor.rowcount > 0:
            return True, "角色删除成功"
        else:
            return False, "未找到该角色"
    except Exception as e:
        print(f"删除角色失败: {e}")
        conn.rollback()
        return False, f"删除失败: {str(e)}"
    finally:
        cursor.close()
        conn.close()