from flask import Blueprint, jsonify, request
from database.models import get_all_characters, add_character, update_character, delete_character

characters_bp = Blueprint('characters', __name__)

@characters_bp.route('/api/characters', methods=['GET'])
def api_characters():
    data = get_all_characters()
    return jsonify({'characters': data})

@characters_bp.route('/api/characters/add', methods=['POST'])
def api_add_character():
    data = request.get_json()
    name = data.get('name')
    gender = data.get('gender')
    age = data.get('age') 
    personality_traits = data.get('personality_traits')
    faction = data.get('faction')
    mbti_type = data.get('mbti_type')

    if not name or not gender:
        return jsonify({'success': False, 'message': '姓名和性别为必填项'}), 400

    success, message = add_character(name, gender, age, personality_traits, faction, mbti_type)
    if success:
        return jsonify({'success': True, 'message': message}), 201 
    else:
        return jsonify({'success': False, 'message': message}), 500

# ✨✨✨ 修改：更新角色信息现在使用 PUT 方法 ✨✨✨
@characters_bp.route('/api/characters/<int:character_id>', methods=['PUT'])
def api_update_character(character_id):
    data = request.get_json()
    name = data.get('name')
    gender = data.get('gender')
    age = data.get('age')
    personality_traits = data.get('personality_traits')
    faction = data.get('faction')
    mbti_type = data.get('mbti_type')

    if not name or not gender:
        return jsonify({'success': False, 'message': '姓名和性别为必填项'}), 400

    success, message = update_character(character_id, name, gender, age, personality_traits, faction, mbti_type)
    if success:
        return jsonify({'success': True, 'message': message})
    else:
        return jsonify({'success': False, 'message': message}), 500

# ✨✨✨ 新增路由：删除角色 ✨✨✨
@characters_bp.route('/api/characters/<int:character_id>', methods=['DELETE'])
def api_delete_character(character_id):
    success, message = delete_character(character_id)
    if success:
        return jsonify({'success': True, 'message': message})
    else:
        return jsonify({'success': False, 'message': message}), 500