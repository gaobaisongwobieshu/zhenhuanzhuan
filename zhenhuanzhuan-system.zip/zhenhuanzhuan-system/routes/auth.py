from flask import Blueprint, request, jsonify

auth_bp = Blueprint('auth', __name__)

# 修改账号密码 

VALID_USERNAME = 'gaobaisongwobieshu'
VALID_PASSWORD = '20050813j' 

@auth_bp.route('/api/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    
    if username == VALID_USERNAME and password == VALID_PASSWORD:
        return jsonify({'success': True, 'redirect': 'index.html'})
    else:
        return jsonify({'success': False, 'message': '用户名或密码错误'})