from flask import Blueprint, jsonify
from database.models import get_all_relationships

relationships_bp = Blueprint('relationships', __name__)

@relationships_bp.route('/api/relationships', methods=['GET'])
def api_relationships():
    data = get_all_relationships()
    return jsonify({'relationships': data})