from flask import Blueprint, jsonify, request
from database.models import get_all_events, get_participants_for_event, update_event_importance

events_bp = Blueprint('events', __name__)

@events_bp.route('/api/events', methods=['GET'])
def api_events():
    data = get_all_events()
    return jsonify({'events': data})

# 获取事件参与者 
@events_bp.route('/api/events/<int:event_id>/participants', methods=['GET'])
def api_event_participants(event_id):
    data = get_participants_for_event(event_id)
    return jsonify(data)

# 更新事件重要性 
@events_bp.route('/api/events/<int:event_id>/update_importance', methods=['POST'])
def api_update_importance(event_id):
    data = request.get_json()
    new_importance = data.get('importance')
    if new_importance not in ['高', '中', '低']:
        return jsonify({'success': False, 'message': '无效的重要性等级'}), 400
    
    success = update_event_importance(event_id, new_importance)
    if success:
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'message': '数据库更新失败'}), 500