from flask import Blueprint, jsonify
from database.models import get_faction_stats, get_events_by_year_stats

statistics_bp = Blueprint('statistics', __name__)

@statistics_bp.route('/api/statistics/factions', methods=['GET'])
def api_faction_stats():
    data = get_faction_stats()
    return jsonify(data)

@statistics_bp.route('/api/statistics/events_by_year', methods=['GET'])
def api_event_stats():
    data = get_events_by_year_stats()
    return jsonify(data)